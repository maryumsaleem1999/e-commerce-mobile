<?php
ob_start();
//include haeder filee
include ('header.php');
?>
  
  
<?php
//include new-phones filee
include ('Template/_adminlogin.php');
?>

<?php
//include footer filee
include ('footer.php');
?>
