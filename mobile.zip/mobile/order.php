<?php
ob_start();
//include haeder filee
include ('header.php');
?>
  
  
<?php
//include new-phones filee
include ('Template/_order.php');
?>

<?php
//include footer filee
include ('footer.php');
?>
