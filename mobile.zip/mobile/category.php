<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lucky Mobile | Catergory</title>
</head>
<body>
    
</body>
</html>

<?php
ob_start();
//include haeder filee
include ('header.php');
?>
  
<?php


//include special-price filee
include ('Template/_category.php');


//include banner-ads filee
include ('Template/_banner-ads.php');



//include footer filee
include ('footer.php');
?>






 