<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lucky Mobile | Contact Us</title>
</head>
<body>
    
</body>
</html>

<?php
ob_start();
//include haeder filee
include ('header.php');
?>
  
<?php
//include banner filee

//include new-phones filee
include ('Template/_contact.php');
?>

<?php
//include footer filee
include ('footer.php');
?>






 