<?php
ob_start();
//include haeder filee
include ('header.php');
?>

<?php

//include product filee
include ('Template/_welcome.php');
 

?>

<?php
//include footer filee
include ('footer.php');
?>
