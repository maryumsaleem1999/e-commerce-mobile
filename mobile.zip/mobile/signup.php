<?php

//include haeder filee
include ('header.php');
?>
  
  
<?php
//include new-phones filee
include ('Template/_signup.php');
?>

<?php
//include footer filee
include ('footer.php');
?>
