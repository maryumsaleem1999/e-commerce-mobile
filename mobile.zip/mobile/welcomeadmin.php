<?php
ob_start();
//include haeder filee
include ('header.php');
?>
  
  
<?php
//include new-phones filee
include ('Template/_welocmeadmintry.php');
?>

<?php
//include footer filee
include ('footer.php');
?>
