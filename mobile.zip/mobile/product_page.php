<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lucky Mobile | Home</title>
</head>
<body>
    
</body>
</html>

<?php
ob_start();
//include haeder filee
include ('header.php');
?>
  
<?php





include ('Template/_product_page.php');
?>

<?php
//include footer filee
include ('footer.php');
?>






 